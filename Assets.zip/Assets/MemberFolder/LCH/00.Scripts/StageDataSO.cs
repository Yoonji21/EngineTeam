using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName ="SO/Data/Stage")]
public class StageDataSO : ScriptableObject
{
	public int StageClear = 0;
}

